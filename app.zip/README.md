<p>This is a very simple personal feedback system. End user can send message anonymously either with or without subject.
every necessary files are given. By default the register option is disabled.You can modify this.
the default dashboard address is: localhost:8000/check/messages </p>
<br> Default email: admin@admin.com
<br> Default pass: admin123
